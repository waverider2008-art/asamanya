import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('order_date', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { customer_name, email, phone, address, items, total } = req.body;
      if (!customer_name || !email || !items || !total) {
        return res.status(400).json({ error: 'Missing required fields' });
      }

      // Insert order
      const { data: orderData, error: orderError } = await supabase
        .from('orders')
        .insert({
          customer_name,
          email,
          phone: phone || '',
          address,
          items,
          total,
          status: 'pending',
          shipment_details: null
        })
        .select()
        .single();

      if (orderError) throw orderError;

      // Update stock for each item 
      // Note: In a real app we'd use transactions. For demo we skip detailed update
      for (const item of items) {
        const { data: prod } = await supabase.from('products').select('stock').eq('id', item.id).single();
        if (prod) {
          await supabase
            .from('products')
            .update({ stock: Math.max(0, prod.stock - item.quantity) })
            .eq('id', item.id);
        }
      }

      return res.status(201).json(orderData);
    }

    if (req.method === 'PUT') {
      const { id, status, shipment_details } = req.body;
      if (!id) return res.status(400).json({ error: 'Missing id' });
      const updates = {};
      if (status) updates.status = status;
      if (shipment_details) updates.shipment_details = shipment_details;
      const { data, error } = await supabase
        .from('orders')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}

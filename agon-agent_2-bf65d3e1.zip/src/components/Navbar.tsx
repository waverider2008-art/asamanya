import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, User, Menu, X } from 'lucide-react';

const Navbar = ({ cartCount, onCartClick, onAdminClick }) => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-md z-50 border-b border-[#d4af37]/10">
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between h-20">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-8 h-8 bg-[#3f2a1e] rounded-full flex items-center justify-center">
            <span className="text-[#d4af37] text-xl">A</span>
          </div>
          <div>
            <div className="font-light text-3xl tracking-[2px] text-[#3f2a1e]">ASAMANYA</div>
            <div className="text-[10px] -mt-1 text-[#9c8a6f]">minimal jewelry</div>
          </div>
        </Link>

        <div className="hidden md:flex items-center gap-10 text-sm uppercase tracking-widest">
          <Link to="/" className="hover:text-[#d4af37] transition-colors">Home</Link>
          <Link to="/shop" className="hover:text-[#d4af37] transition-colors">Shop</Link>
          <Link to="/about" className="hover:text-[#d4af37] transition-colors">About</Link>
          <Link to="/contact" className="hover:text-[#d4af37] transition-colors">Contact</Link>
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={onAdminClick}
            className="flex items-center gap-2 px-5 py-2.5 text-xs border border-[#d4af37]/40 rounded-full hover:bg-[#d4af37]/5 transition"
          >
            <User size={15} /> ADMIN
          </button>

          <button 
            onClick={onCartClick}
            className="relative flex h-11 w-11 items-center justify-center rounded-full border border-[#d4af37]/30 hover:bg-[#f8f5f2] transition"
          >
            <ShoppingCart size={19} />
            {cartCount > 0 && (
              <div className="absolute -top-1 -right-1 bg-[#d4af37] text-[#3f2a1e] text-[10px] font-medium h-5 w-5 rounded-full flex items-center justify-center">
                {cartCount}
              </div>
            )}
          </button>

          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden"
          >
            {isMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t px-6 py-8 flex flex-col gap-6 text-lg">
          <Link to="/" onClick={() => setIsMenuOpen(false)}>Home</Link>
          <Link to="/shop" onClick={() => setIsMenuOpen(false)}>Shop</Link>
          <Link to="/about" onClick={() => setIsMenuOpen(false)}>About Us</Link>
          <Link to="/contact" onClick={() => setIsMenuOpen(false)}>Contact</Link>
        </div>
      )}
    </nav>
  );
};

export default Navbar;

const About = () => {
  return (
    <div className="pt-24 pb-24 px-6 max-w-3xl mx-auto">
      <div className="text-center mb-16">
        <div className="uppercase tracking-widest text-xs text-[#d4af37]">OUR STORY</div>
        <h1 className="text-6xl font-light mt-4">Asamanya</h1>
      </div>
      
      <div className="prose prose-lg mx-auto text-[#6b5743]">
        <p className="text-xl leading-relaxed">Born from the heart of Bengal, Asamanya was founded with a simple belief: every woman deserves to feel extraordinary with just a touch of minimal jewelry.</p>
        
        <p>Our name, meaning "extraordinary" in Bengali, reflects our mission to create pieces that enhance natural beauty without overwhelming it. We carefully select materials to craft costume jewelry that looks and feels luxurious yet remains accessible.</p>
        
        <div className="my-16 grid grid-cols-1 md:grid-cols-2 gap-10">
          <div>
            <h3 className="font-medium text-2xl mb-4">Our Promise</h3>
            <ul className="space-y-4 text-base">
              <li>✔ Handcrafted with passion</li>
              <li>✔ Fair prices for everyone</li>
              <li>✔ Hypoallergenic materials</li>
              <li>✔ Fast shipping across India</li>
            </ul>
          </div>
          <div>
            <h3 className="font-medium text-2xl mb-4">Our Values</h3>
            <p>Quality over quantity. Simplicity over excess. Beauty in the everyday.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;

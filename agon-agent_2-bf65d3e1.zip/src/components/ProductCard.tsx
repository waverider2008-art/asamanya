import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';

const ProductCard = ({ product, onQuickView, onAddToCart }) => {
  return (
    <motion.div 
      whileHover={{ y: -8 }}
      className="group bg-white rounded-3xl overflow-hidden shadow-sm border border-[#f0e9e0] flex flex-col h-full"
    >
      <div className="relative h-[320px] overflow-hidden">
        <img 
          src={product.image_url} 
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute top-4 right-4 bg-white px-3 py-1 text-xs rounded-full shadow font-mono tracking-widest">
          ₹{product.price}
        </div>
        {product.stock < 10 && (
          <div className="absolute bottom-4 left-4 bg-amber-500 text-white text-[10px] px-3 py-px rounded">LOW STOCK</div>
        )}
      </div>
      
      <div className="p-8 flex flex-col flex-1">
        <div>
          <div className="uppercase text-[#d4af37] text-xs tracking-[1.5px] mb-2">{product.category}</div>
          <h3 className="font-light text-2xl tracking-tight mb-3 leading-none">{product.name}</h3>
          <p className="text-[#6b5743] text-sm line-clamp-3">{product.description}</p>
        </div>
        
        <div className="mt-auto pt-8 flex gap-3">
          <button 
            onClick={() => onQuickView(product)}
            className="flex-1 border border-[#d4af37] hover:bg-[#d4af37] hover:text-white py-3.5 text-sm tracking-widest transition"
          >
            QUICK VIEW
          </button>
          <button 
            onClick={() => onAddToCart(product)}
            className="flex-1 bg-[#3f2a1e] text-white py-3.5 text-sm tracking-widest flex items-center justify-center gap-2 hover:bg-black transition"
          >
            <Plus size={16} /> ADD
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;

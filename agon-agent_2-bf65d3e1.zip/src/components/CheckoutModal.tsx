import { X } from 'lucide-react';
import { useState } from 'react';
import { motion } from 'framer-motion';

const CheckoutModal = ({ isOpen, onClose, onSubmit, cartTotal, cartItems }) => {
  const [formData, setFormData] = useState({
    customer_name: '',
    email: '',
    phone: '',
    address: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    await onSubmit(formData);
    setIsSubmitting(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[130] p-4">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white rounded-3xl max-w-lg w-full overflow-hidden"
      >
        <div className="px-10 pt-10 pb-8">
          <div className="flex justify-between items-start mb-9">
            <div>
              <div className="uppercase tracking-[3px] text-xs text-[#d4af37]">CHECKOUT</div>
              <div className="text-4xl font-light mt-1">Complete your order</div>
            </div>
            <button onClick={onClose} className="text-[#9c8a6f]"><X size={26} /></button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-xs tracking-widest mb-2">FULL NAME</label>
              <input 
                type="text" 
                name="customer_name" 
                value={formData.customer_name} 
                onChange={handleChange}
                required
                className="w-full border-b border-[#d4af37]/30 py-4 focus:outline-none text-lg placeholder:text-[#d4af37]/40" 
                placeholder="Priya Sharma" 
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs tracking-widest mb-2">EMAIL ADDRESS</label>
                <input 
                  type="email" 
                  name="email" 
                  value={formData.email} 
                  onChange={handleChange}
                  required
                  className="w-full border-b border-[#d4af37]/30 py-4 focus:outline-none text-lg placeholder:text-[#d4af37]/40" 
                  placeholder="hello@email.com" 
                />
              </div>
              <div>
                <label className="block text-xs tracking-widest mb-2">PHONE</label>
                <input 
                  type="tel" 
                  name="phone" 
                  value={formData.phone} 
                  onChange={handleChange}
                  className="w-full border-b border-[#d4af37]/30 py-4 focus:outline-none text-lg placeholder:text-[#d4af37]/40" 
                  placeholder="+91 98765 43210" 
                />
              </div>
            </div>

            <div>
              <label className="block text-xs tracking-widest mb-2">DELIVERY ADDRESS</label>
              <textarea 
                name="address" 
                value={formData.address} 
                onChange={handleChange}
                required
                rows={3}
                className="w-full border border-[#d4af37]/30 p-5 focus:outline-none rounded-2xl resize-y min-h-[110px]" 
                placeholder="House No, Street, City, PIN Code"
              />
            </div>

            <div className="pt-4 border-t flex justify-between items-end text-xl">
              <div>TOTAL AMOUNT</div>
              <div className="font-light">₹{cartTotal}</div>
            </div>

            <button 
              type="submit"
              disabled={isSubmitting}
              className="mt-4 w-full py-5 bg-[#3f2a1e] text-white text-sm tracking-[3px] disabled:opacity-60"
            >
              {isSubmitting ? 'PROCESSING...' : 'PLACE ORDER • CASH ON DELIVERY'}
            </button>
            
            <div className="text-center text-xs text-[#9c8a6f]">We will contact you shortly for confirmation</div>
          </form>
        </div>
      </motion.div>
    </div>
  );
};

export default CheckoutModal;

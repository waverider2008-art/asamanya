import { X, Plus, Minus, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useCart } from '../context/CartContext';

const Cart = ({ isOpen, onClose, onCheckout }) => {
  const { cart, removeFromCart, updateQuantity, getTotal } = useCart();

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <div className="fixed inset-0 bg-black/60 z-[110]" onClick={onClose} />
          
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 26 }}
            className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-white z-[120] shadow-2xl flex flex-col"
          >
            <div className="p-8 border-b flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="text-3xl">🛍️</div>
                <div>
                  <div className="font-medium tracking-widest">YOUR CART</div>
                  <div className="text-xs text-[#9c8a6f]">{cart.length} ITEMS</div>
                </div>
              </div>
              <button onClick={onClose}><X /></button>
            </div>

            <div className="flex-1 p-8 overflow-auto">
              {cart.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center">
                  <div className="text-6xl mb-6 opacity-40">🛍️</div>
                  <p className="font-light">Your cart is empty</p>
                  <p className="text-sm text-[#9c8a6f] mt-1">Discover our collection</p>
                </div>
              ) : (
                <div className="space-y-8">
                  {cart.map(item => (
                    <div key={item.id} className="flex gap-6">
                      <div className="w-24 h-24 flex-shrink-0 rounded-2xl overflow-hidden border border-[#f0e9e0]">
                        <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between">
                          <div className="font-light pr-8">{item.name}</div>
                          <div>₹{item.price}</div>
                        </div>
                        
                        <div className="flex items-center justify-between mt-6">
                          <div className="flex border border-[#d4af37]/30 rounded">
                            <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="px-3 py-1 hover:bg-[#f8f5f2]">-</button>
                            <div className="px-4 py-1 border-x border-[#d4af37]/30">{item.quantity}</div>
                            <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="px-3 py-1 hover:bg-[#f8f5f2]">+</button>
                          </div>
                          
                          <button onClick={() => removeFromCart(item.id)} className="text-red-500 hover:text-red-700">
                            <Trash2 size={17} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {cart.length > 0 && (
              <div className="p-8 border-t bg-[#f8f5f2]">
                <div className="flex justify-between mb-8 text-xl">
                  <div>TOTAL</div>
                  <div>₹{getTotal()}</div>
                </div>
                
                <button 
                  onClick={onCheckout}
                  className="w-full py-4 bg-[#3f2a1e] text-white tracking-[2px] text-sm hover:bg-black transition"
                >
                  PROCEED TO CHECKOUT
                </button>
                <div className="text-center text-xs mt-4 text-[#9c8a6f]">Cash on Delivery Available</div>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default Cart;

import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const Hero = () => {
  return (
    <div className="relative h-screen flex items-center justify-center overflow-hidden pt-20">
      <div className="absolute inset-0 bg-[radial-gradient(#d4af37_0.5px,transparent_1px)] bg-[length:4px_4px] opacity-20"></div>
      
      <img 
        src="/images/hero.jpg" 
        alt="Elegant jewelry" 
        className="absolute inset-0 w-full h-full object-cover" 
      />
      
      <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/40 to-black/70"></div>
      
      <div className="relative z-10 text-center px-6 max-w-3xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="text-[#d4af37] uppercase tracking-[4px] text-sm mb-6">BENGALI FOR EXTRAORDINARY</div>
          <h1 className="text-white text-7xl md:text-[92px] font-light leading-none tracking-[-2px] mb-8">
            ASAMANYA
          </h1>
          <p className="text-white/90 max-w-md mx-auto text-xl mb-12">
            Minimal jewelry that celebrates the extraordinary in you
          </p>
          
          <Link 
            to="/shop"
            className="inline-block px-14 py-4 bg-white text-[#3f2a1e] font-medium tracking-widest text-sm hover:bg-[#d4af37] hover:text-white transition-all duration-300"
          >
            EXPLORE COLLECTION
          </Link>
        </motion.div>
      </div>
      
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center text-white/70 text-xs tracking-widest">
        SCROLL TO DISCOVER
        <motion.div 
          animate={{ y: [0, 12, 0] }} 
          transition={{ duration: 2.2, repeat: Infinity }}
          className="mt-2"
        >
          ↓
        </motion.div>
      </div>
    </div>
  );
};

export default Hero;

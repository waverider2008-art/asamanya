import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const ProductModal = ({ product, isOpen, onClose, onAddToCart }) => {
  if (!product || !isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[100] p-4" onClick={onClose}>
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 40 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 40 }}
          className="bg-white max-w-3xl w-full rounded-3xl overflow-hidden" 
          onClick={e => e.stopPropagation()}
        >
          <div className="grid md:grid-cols-2">
            <div className="relative h-96 md:h-auto bg-[#f8f5f2]">
              <img 
                src={product.image_url} 
                alt={product.name} 
                className="absolute inset-0 w-full h-full object-cover" 
              />
            </div>
            
            <div className="p-10 flex flex-col">
              <button onClick={onClose} className="self-end text-[#9c8a6f]">
                <X size={22} />
              </button>
              
              <div className="mt-2">
                <div className="uppercase text-xs tracking-[2px] text-[#d4af37] mb-1">{product.category}</div>
                <h2 className="text-4xl font-light tracking-tight mb-3">{product.name}</h2>
                <div className="text-4xl mb-8">₹{product.price}</div>
              </div>

              <div className="text-[#6b5743] flex-1">
                {product.description}
                <div className="mt-8 text-xs uppercase tracking-widest">STOCK: {product.stock} REMAINING</div>
              </div>

              <button 
                onClick={() => {
                  onAddToCart(product);
                  onClose();
                }}
                className="mt-8 w-full py-4 bg-[#3f2a1e] text-white text-sm tracking-[2px] hover:bg-black"
              >
                ADD TO CART
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default ProductModal;

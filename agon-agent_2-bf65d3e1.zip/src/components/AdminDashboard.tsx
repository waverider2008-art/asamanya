import { useState, useEffect } from 'react';
import supabase from '../lib/supabase';
import { Plus, Edit2, Trash2, Package, Truck } from 'lucide-react';

const AdminDashboard = ({ onProductUpdate }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [activeTab, setActiveTab] = useState('products');
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [newProduct, setNewProduct] = useState({
    name: '', description: '', price: '', category: 'Necklaces', stock: 50, image_url: ''
  });
  const [message, setMessage] = useState('');

  // Demo credentials
  const demoEmail = 'admin@asamanya.in';
  const demoPass = 'asamanya123';

  const handleLogin = async (e) => {
    e.preventDefault();
    // For demo use hardcoded, in production use supabase.auth.signInWithPassword
    if (email === demoEmail && password === demoPass) {
      setIsLoggedIn(true);
      fetchAdminData();
    } else {
      setMessage('Invalid credentials. Use admin@asamanya.in / asamanya123');
    }
  };

  const fetchAdminData = async () => {
    // Products
    const prodRes = await fetch('/api/products');
    const prodData = await prodRes.json();
    setProducts(prodData);

    // Orders
    const ordRes = await fetch('/api/orders');
    const ordData = await ordRes.json();
    setOrders(ordData);
  };

  const saveProduct = async () => {
    const payload = {
      ...newProduct,
      price: parseFloat(newProduct.price)
    };

    let res;
    if (editingProduct) {
      res = await fetch('/api/products', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: editingProduct.id, ...payload })
      });
    } else {
      res = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    }

    if (res.ok) {
      setMessage(editingProduct ? 'Product updated!' : 'Product added!');
      setShowAddForm(false);
      setEditingProduct(null);
      setNewProduct({ name: '', description: '', price: '', category: 'Necklaces', stock: 50, image_url: '' });
      fetchAdminData();
      if (onProductUpdate) onProductUpdate();
    }
  };

  const deleteProduct = async (id) => {
    if (!confirm('Delete this product?')) return;
    const res = await fetch('/api/products', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    if (res.ok) {
      fetchAdminData();
      setMessage('Product deleted');
    }
  };

  const updateOrderStatus = async (id, status) => {
    const res = await fetch('/api/orders', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, status })
    });
    if (res.ok) fetchAdminData();
  };

  const logout = () => {
    setIsLoggedIn(false);
    setEmail('');
    setPassword('');
  };

  useEffect(() => {
    if (isLoggedIn) fetchAdminData();
  }, [isLoggedIn]);

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f8f5f2]">
        <div className="max-w-md w-full px-8 py-12 bg-white rounded-3xl shadow">
          <div className="text-center mb-12">
            <div className="mx-auto w-16 h-16 bg-[#3f2a1e] rounded-2xl flex items-center justify-center text-[#d4af37] text-4xl mb-6">A</div>
            <div className="text-4xl font-light">Admin Portal</div>
          </div>
          
          <form onSubmit={handleLogin} className="space-y-5">
            <input 
              type="email" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)} 
              placeholder="Email" 
              className="w-full py-4 px-6 border border-[#d4af37]/30 rounded-2xl" 
            />
            <input 
              type="password" 
              value={password} 
              onChange={(e) => setPassword(e.target.value)} 
              placeholder="Password" 
              className="w-full py-4 px-6 border border-[#d4af37]/30 rounded-2xl" 
            />
            <button type="submit" className="w-full py-4 bg-[#3f2a1e] text-white rounded-2xl">SIGN IN</button>
          </form>
          
          <div className="text-xs text-center mt-8 text-[#9c8a6f]">
            Demo: admin@asamanya.in / asamanya123
          </div>
          {message && <div className="text-center text-red-500 mt-3 text-sm">{message}</div>}
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 pb-12 px-6 bg-[#f8f5f2] min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-12">
          <div>
            <div className="text-xs tracking-widest text-[#d4af37]">OWNER DASHBOARD</div>
            <div className="text-5xl font-light">Asamanya Admin</div>
          </div>
          <button onClick={logout} className="text-sm px-6 py-3 border">LOGOUT</button>
        </div>

        <div className="flex border-b mb-10">
          <button onClick={() => setActiveTab('products')} className={`px-8 py-4 font-medium flex items-center gap-2 ${activeTab === 'products' ? 'border-b-2 border-[#3f2a1e]' : ''}`}>
            <Package size={18} /> PRODUCTS
          </button>
          <button onClick={() => setActiveTab('orders')} className={`px-8 py-4 font-medium flex items-center gap-2 ${activeTab === 'orders' ? 'border-b-2 border-[#3f2a1e]' : ''}`}>
            <Truck size={18} /> ORDERS
          </button>
        </div>

        {message && <div className="mb-6 p-3 bg-emerald-100 text-emerald-700 rounded">{message}</div>}

        {activeTab === 'products' && (
          <>
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl">Inventory</h2>
              <button onClick={() => { setShowAddForm(true); setEditingProduct(null); }} className="flex items-center gap-2 bg-[#3f2a1e] text-white px-6 py-3 rounded-2xl text-sm">
                <Plus size={18} /> ADD NEW PRODUCT
              </button>
            </div>

            <div className="bg-white rounded-3xl overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-5 px-8 font-normal text-xs tracking-widest">PRODUCT</th>
                    <th className="text-left py-5 px-8 font-normal text-xs tracking-widest">CATEGORY</th>
                    <th className="text-left py-5 px-8 font-normal text-xs tracking-widest">PRICE</th>
                    <th className="text-left py-5 px-8 font-normal text-xs tracking-widest">STOCK</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {products.map(p => (
                    <tr key={p.id} className="border-b last:border-none">
                      <td className="py-6 px-8 flex items-center gap-4">
                        <img src={p.image_url} className="w-12 h-12 object-cover rounded-lg" />
                        <div>{p.name}</div>
                      </td>
                      <td className="py-6 px-8 text-sm text-[#9c8a6f]">{p.category}</td>
                      <td className="py-6 px-8">₹{p.price}</td>
                      <td className="py-6 px-8">{p.stock}</td>
                      <td className="py-6 px-8 text-right">
                        <button onClick={() => { setEditingProduct(p); setNewProduct({...p}); setShowAddForm(true); }} className="mr-4"><Edit2 size={17} /></button>
                        <button onClick={() => deleteProduct(p.id)}><Trash2 size={17} /></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}

        {activeTab === 'orders' && (
          <div>
            <h2 className="text-2xl mb-8">Recent Orders</h2>
            <div className="space-y-6">
              {orders.length === 0 ? <div>No orders yet.</div> : orders.map(order => (
                <div key={order.id} className="bg-white p-8 rounded-3xl flex flex-col md:flex-row gap-8">
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <div>
                        <div className="font-medium text-xl">{order.customer_name}</div>
                        <div className="text-sm text-[#9c8a6f]">{order.email}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono">₹{order.total}</div>
                        <div className="text-xs mt-1 uppercase">{new Date(order.order_date).toLocaleDateString()}</div>
                      </div>
                    </div>
                    
                    <div className="mt-8 text-xs uppercase tracking-widest">ITEMS</div>
                    <ul className="mt-3 space-y-1 text-sm">
                      {order.items && order.items.map((it, idx) => (
                        <li key={idx}>{it.quantity} × {it.name}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="md:w-64 pt-2">
                    <div className="uppercase text-xs tracking-widest mb-2">STATUS</div>
                    <select 
                      value={order.status} 
                      onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                      className="border px-5 py-3 w-full rounded-xl bg-white"
                    >
                      <option value="pending">Pending</option>
                      <option value="shipped">Shipped</option>
                      <option value="delivered">Delivered</option>
                    </select>
                    <div className="text-xs mt-6 opacity-60">SHIPMENT DETAILS: {order.shipment_details || '—'}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Add/Edit Product Modal */}
        {showAddForm && (
          <div className="fixed inset-0 bg-black/70 z-[200] flex items-center justify-center p-4">
            <div className="bg-white max-w-lg w-full rounded-3xl p-10">
              <h3 className="text-2xl mb-8">{editingProduct ? 'Edit Product' : 'Add New Product'}</h3>
              
              <div className="space-y-6">
                <input 
                  value={newProduct.name} 
                  onChange={e => setNewProduct({...newProduct, name: e.target.value})} 
                  placeholder="Product Name" 
                  className="border-b w-full py-4" 
                />
                <textarea 
                  value={newProduct.description} 
                  onChange={e => setNewProduct({...newProduct, description: e.target.value})} 
                  placeholder="Description" 
                  className="border w-full p-4 h-28" 
                />
                <div className="grid grid-cols-2 gap-6">
                  <input 
                    type="number" 
                    value={newProduct.price} 
                    onChange={e => setNewProduct({...newProduct, price: e.target.value})} 
                    placeholder="Price in ₹" 
                    className="border-b py-4" 
                  />
                  <select 
                    value={newProduct.category} 
                    onChange={e => setNewProduct({...newProduct, category: e.target.value})} 
                    className="border-b py-4 bg-white"
                  >
                    <option>Necklaces</option>
                    <option>Earrings</option>
                    <option>Bracelets</option>
                    <option>Rings</option>
                    <option>Anklets</option>
                  </select>
                </div>
                <input 
                  type="number" 
                  value={newProduct.stock} 
                  onChange={e => setNewProduct({...newProduct, stock: parseInt(e.target.value)})} 
                  placeholder="Stock" 
                  className="border-b w-full py-4" 
                />
                <input 
                  value={newProduct.image_url} 
                  onChange={e => setNewProduct({...newProduct, image_url: e.target.value})} 
                  placeholder="Image URL (use /images/xxx.jpg)" 
                  className="border-b w-full py-4" 
                />
              </div>
              
              <div className="flex gap-3 mt-12">
                <button onClick={() => {setShowAddForm(false); setEditingProduct(null);}} className="flex-1 py-4 border">CANCEL</button>
                <button onClick={saveProduct} className="flex-1 py-4 bg-[#3f2a1e] text-white">SAVE PRODUCT</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;

const Contact = () => {
  return (
    <div className="pt-24 pb-24 px-6 max-w-3xl mx-auto">
      <div className="text-center">
        <div className="uppercase text-xs tracking-widest mb-4 text-[#d4af37]">GET IN TOUCH</div>
        <h1 className="text-6xl font-light">We'd love to hear from you</h1>
      </div>
      
      <div className="mt-16 grid md:grid-cols-2 gap-16">
        <div>
          <div className="text-sm uppercase tracking-widest mb-8">VISIT OUR STUDIO</div>
          <div className="font-light text-2xl">Kolkata, West Bengal</div>
          <div className="mt-2 text-[#6b5743]">India</div>
          
          <div className="mt-12">
            <div className="text-xs tracking-widest mb-3">EMAIL US</div>
            <a href="mailto:hello@asamanya.in" className="block text-xl hover:underline">hello@asamanya.in</a>
          </div>
          
          <div className="mt-12">
            <div className="text-xs tracking-widest mb-3">CALL US</div>
            <a href="tel:+919876543210" className="block text-xl hover:underline">+91 98765 43210</a>
          </div>
        </div>
        
        <div className="bg-[#f8f5f2] p-10 rounded-3xl text-sm">
          <p className="mb-8">We respond to all messages within 24 hours. For wholesale inquiries please mention your business details.</p>
          
          <form className="space-y-7">
            <input type="text" placeholder="YOUR NAME" className="w-full py-4 border-b bg-transparent focus:outline-none" />
            <input type="email" placeholder="EMAIL ADDRESS" className="w-full py-4 border-b bg-transparent focus:outline-none" />
            <textarea placeholder="YOUR MESSAGE" rows={5} className="w-full py-4 border-b bg-transparent focus:outline-none resize-y" />
            <button type="button" className="mt-4 px-12 py-4 bg-black text-white text-xs tracking-widest">SEND MESSAGE</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contact;

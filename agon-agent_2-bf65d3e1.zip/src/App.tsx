import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { ShoppingCart, User, Menu, X, Plus, Minus, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ProductCard from './components/ProductCard';
import ProductModal from './components/ProductModal';
import Cart from './components/Cart';
import CheckoutModal from './components/CheckoutModal';
import About from './components/About';
import Contact from './components/Contact';
import AdminDashboard from './components/AdminDashboard';
import { CartProvider, useCart } from './context/CartContext';

function MainContent() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showCart, setShowCart] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [showToast, setShowToast] = useState(null);

  const { cart, addToCart, removeFromCart, updateQuantity, getTotal, clearCart } = useCart();

  const categories = ['All', 'Necklaces', 'Earrings', 'Bracelets', 'Rings', 'Anklets'];

  const fetchProducts = async () => {
    try {
      const res = await fetch('/api/products');
      const data = await res.json();
      setProducts(data);
    } catch (err) {
      console.error('Failed to fetch products:', err);
      setShowToast({ type: 'error', message: 'Failed to load products' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const filteredProducts = products
    .filter(p => {
      const matchesCategory = activeCategory === 'All' || p.category === activeCategory;
      const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           (p.description && p.description.toLowerCase().includes(searchTerm.toLowerCase()));
      return matchesCategory && matchesSearch;
    });

  const handleAddToCart = (product) => {
    addToCart(product);
    setShowToast({ type: 'success', message: `${product.name} added to cart` });
    setTimeout(() => setShowToast(null), 2000);
  };

  const handleCheckout = () => {
    if (cart.length === 0) return;
    setShowCart(false);
    setShowCheckout(true);
  };

  const completeOrder = async (customerInfo) => {
    const itemsForOrder = cart.map(item => ({
      id: item.id,
      name: item.name,
      price: item.price,
      quantity: item.quantity
    }));

    const total = getTotal();

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...customerInfo,
          items: itemsForOrder,
          total
        })
      });

      if (res.ok) {
        const order = await res.json();
        setShowToast({ type: 'success', message: 'Order placed successfully! Thank you.' });
        clearCart();
        setShowCheckout(false);
        // Refresh products to update stock
        fetchProducts();
      } else {
        throw new Error('Failed to place order');
      }
    } catch (err) {
      console.error(err);
      setShowToast({ type: 'error', message: 'Failed to place order. Please try again.' });
    }
  };

  return (
    <div className="min-h-screen bg-[#f8f5f2] text-[#3f2a1e] font-sans">
      <Navbar 
        cartCount={cart.length} 
        onCartClick={() => setShowCart(true)} 
        onAdminClick={() => window.location.href = '/admin'} 
      />

      <Routes>
        <Route path="/" element={
          <>
            <Hero />
            
            {/* Featured Products */}
            <section className="py-16 px-6 max-w-7xl mx-auto">
              <div className="flex flex-col items-center mb-12">
                <div className="text-[#d4af37] text-sm tracking-[3px] uppercase mb-2">Our Collection</div>
                <h2 className="text-5xl font-light tracking-tight text-center">Timeless Pieces</h2>
                <p className="mt-4 max-w-md text-center text-[#6b5743]">Minimal jewelry crafted with love to make every moment extraordinary</p>
              </div>

              {/* Filters */}
              <div className="flex flex-col md:flex-row gap-4 mb-8 items-center justify-between">
                <div className="flex flex-wrap gap-2">
                  {categories.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setActiveCategory(cat)}
                      className={`px-6 py-2 text-sm rounded-full transition-all ${activeCategory === cat 
                        ? 'bg-[#3f2a1e] text-white' 
                        : 'bg-white border border-[#d4af37]/30 hover:bg-[#d4af37]/10'}`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
                
                <div className="relative w-full md:w-80">
                  <input
                    type="text"
                    placeholder="Search jewelry..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-white border border-[#d4af37]/20 rounded-full focus:outline-none focus:border-[#d4af37]"
                  />
                  <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 text-[#9c8a6f] absolute left-4 top-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
              </div>

              {loading ? (
                <div className="flex justify-center py-20">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-[#d4af37]"></div>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                  <AnimatePresence>
                    {filteredProducts.map((product, index) => (
                      <motion.div
                        key={product.id}
                        initial={{ opacity: 0, y: 40 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.03 }}
                      >
                        <ProductCard 
                          product={product} 
                          onQuickView={setSelectedProduct}
                          onAddToCart={handleAddToCart}
                        />
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              )}

              {filteredProducts.length === 0 && !loading && (
                <div className="text-center py-20 text-[#9c8a6f]">
                  No products found matching your criteria.
                </div>
              )}
            </section>

            {/* Values Section */}
            <section className="bg-[#3f2a1e] text-white py-20">
              <div className="max-w-4xl mx-auto px-6 text-center">
                <div className="inline-block bg-[#d4af37] text-[#3f2a1e] px-5 py-1 text-xs tracking-widest rounded mb-6">WHY ASAMANYA</div>
                <h3 className="text-4xl font-light mb-8">Minimalism that Celebrates You</h3>
                <div className="grid md:grid-cols-3 gap-8 mt-12">
                  {[
                    { icon: '💎', title: 'Premium Quality', desc: 'Handpicked materials that last, always ethical' },
                    { icon: '🌿', title: 'Affordable Luxury', desc: 'Beautiful pieces accessible to every woman' },
                    { icon: '♻️', title: 'Conscious Craft', desc: 'Sustainably made with love in small batches' }
                  ].map((val, i) => (
                    <div key={i} className="bg-white/5 backdrop-blur p-8 rounded-3xl">
                      <div className="text-5xl mb-6">{val.icon}</div>
                      <h4 className="text-xl mb-3 font-medium">{val.title}</h4>
                      <p className="opacity-80">{val.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          </>
        } />

        <Route path="/shop" element={
          <div className="pt-20 pb-24 px-6 max-w-7xl mx-auto">
            {/* Shop full page */}
            <div className="text-center mb-12">
              <h1 className="text-6xl font-light tracking-tight">The Collection</h1>
              <p className="mt-4 text-lg text-[#6b5743]">Discover pieces that speak softly yet leave a lasting impression</p>
            </div>
            {/* Reuse the filters and products grid here */}
            {/* ... similar to above, but can extract later */}
            <div className="flex flex-col md:flex-row gap-4 mb-8 items-center justify-between">
              {/* filters same as above */}
            </div>
            {/* grid */}
          </div>
        } />

        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/admin" element={<AdminDashboard onProductUpdate={fetchProducts} />} />
      </Routes>

      <footer className="bg-[#3f2a1e] text-[#d4af37] py-16 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-y-12">
          <div>
            <div className="text-3xl font-light tracking-widest mb-6">ASAMANYA</div>
            <p className="text-sm opacity-70 max-w-[200px]">Minimal jewelry for the extraordinary you.</p>
          </div>
          <div>
            <div className="uppercase text-xs tracking-widest mb-6 text-[#d4af37]">SHOP</div>
            <div className="space-y-2 text-sm">
              <Link to="/shop" className="block hover:text-white transition">Necklaces</Link>
              <Link to="/shop" className="block hover:text-white transition">Earrings</Link>
              <Link to="/shop" className="block hover:text-white transition">Bracelets</Link>
            </div>
          </div>
          <div>
            <div className="uppercase text-xs tracking-widest mb-6 text-[#d4af37]">EXPLORE</div>
            <div className="space-y-2 text-sm">
              <Link to="/about" className="block hover:text-white transition">Our Story</Link>
              <Link to="/contact" className="block hover:text-white transition">Contact Us</Link>
            </div>
          </div>
          <div>
            <div className="uppercase text-xs tracking-widest mb-6 text-[#d4af37]">CONNECT</div>
            <div className="flex gap-5">
              <a href="#" className="hover:text-white">📷</a>
              <a href="#" className="hover:text-white">𝕏</a>
              <a href="#" className="hover:text-white">📘</a>
            </div>
            <p className="mt-8 text-xs opacity-60">© {new Date().getFullYear()} Asamanya. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Product Modal */}
      <ProductModal 
        product={selectedProduct} 
        isOpen={!!selectedProduct} 
        onClose={() => setSelectedProduct(null)} 
        onAddToCart={handleAddToCart} 
      />

      {/* Cart Sidebar */}
      <Cart 
        isOpen={showCart} 
        onClose={() => setShowCart(false)} 
        onCheckout={handleCheckout} 
      />

      {/* Checkout Modal */}
      <CheckoutModal 
        isOpen={showCheckout} 
        onClose={() => setShowCheckout(false)} 
        onSubmit={completeOrder} 
        cartTotal={getTotal()} 
        cartItems={cart} 
      />

      {/* Toast */}
      <AnimatePresence>
        {showToast && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className={`fixed bottom-8 left-1/2 -translate-x-1/2 px-8 py-4 rounded-2xl shadow-xl flex items-center gap-3 z-50
              ${showToast.type === 'success' ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'}`}
          >
            {showToast.type === 'success' ? '✓' : '⚠'} {showToast.message}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function App() {
  return (
    <Router>
      <CartProvider>
        <MainContent />
      </CartProvider>
    </Router>
  );
}

export default App;

